# Autumn AI Chat (Fly.io Prototype)

## Structure

- `app.py` - Flask backend server
- `lead_edge_cryptography.py` - Prototype encryption (Base64)
- `users.json` - Encrypted user database
- `frontend/` - Static files (HTML, CSS, JS)
- `Dockerfile` - Container configuration
- `fly.toml` - Fly.io deployment configuration

## Local Development

1. Build and run:
   ```
   docker build -t autumn-app .
   docker run -p 8080:8080 autumn-app
   ```

2. Visit `http://localhost:8080` to see the login/signup page.

## Deployment

```
fly deploy
```

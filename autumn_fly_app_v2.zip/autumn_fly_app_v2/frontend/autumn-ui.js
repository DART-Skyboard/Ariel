// Placeholder for Autumn chat logic
const chatBox = document.getElementById('chat-box');
const userInput = document.getElementById('user-input');
const sendBtn = document.getElementById('send-btn');

sendBtn.addEventListener('click', () => {
  const msg = userInput.value.trim();
  if (!msg) return;
  const p = document.createElement('p');
  p.textContent = 'You: ' + msg;
  chatBox.appendChild(p);
  userInput.value = '';
  // TODO: call backend reflection API
});

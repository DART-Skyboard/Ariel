let isLogin = true;

const container = document.getElementById('form-container');
const toggleBtn = document.getElementById('toggle-btn');

function renderForm() {
  container.innerHTML = '';
  if (isLogin) {
    container.innerHTML = `
      <div class="form">
        <input type="email" id="email" placeholder="Email">
        <input type="password" id="password" placeholder="Password">
        <button id="submit-btn">Login</button>
        <p id="message"></p>
      </div>`;
    toggleBtn.textContent = "Don't have an account? Sign Up";
  } else {
    container.innerHTML = `
      <div class="form">
        <input type="email" id="email" placeholder="Email">
        <input type="password" id="password" placeholder="Password">
        <label><input type="checkbox" id="agree"> I agree to <a href="https://www.dartmeadow.com/privacy-policy" target="_blank">Privacy Policy</a></label>
        <button id="submit-btn" disabled>Sign Up</button>
        <p id="message"></p>
      </div>`;
    toggleBtn.textContent = "Already have an account? Login";
    document.getElementById('agree').addEventListener('change', (e) => {
      document.getElementById('submit-btn').disabled = !e.target.checked;
    });
  }
  document.getElementById('submit-btn').addEventListener('click', handleSubmit);
}

toggleBtn.addEventListener('click', () => {
  isLogin = !isLogin;
  renderForm();
});

function handleSubmit() {
  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;
  const message = document.getElementById('message');
  if (!/\S+@\S+\.\S+/.test(email)) {
    message.textContent = 'Invalid email format.';
    return;
  }
  if (password.length < 6) {
    message.textContent = 'Password must be at least 6 characters.';
    return;
  }
  // Encrypt credentials
  // Using global lead_edge_cryptography from Flask static import
  const encEmail = window.LEAD_EDGE.encrypt(email);
  const encPassword = window.LEAD_EDGE.encrypt(password);
  const url = isLogin ? '/login' : '/signup';
  fetch(url, {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({email: encEmail, password: encPassword})
  })
    .then(res => res.json())
    .then(data => {
      if (data.success) {
        window.location.href = '/chat';
      } else {
        message.textContent = data.error || 'Error occurred';
      }
    })
    .catch(() => {
      message.textContent = 'Network error';
    });
}

renderForm();

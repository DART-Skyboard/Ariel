import os
from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from lead_edge_model import AutumnReflex

app = Flask(__name__, static_folder='frontend', static_url_path='')
app.config['SQLALCHEMY_DATABASE_URI'] = os.getenv('DATABASE_URL', 'sqlite:///users.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    encrypted_email = db.Column(db.String, unique=True, nullable=False)
    encrypted_password = db.Column(db.String, nullable=False)

db.create_all()

autumn = AutumnReflex()

@app.route('/api/signup', methods=['POST'])
def signup():
    data = request.json
    enc_email = data.get('email')
    enc_password = data.get('password')
    email = autumn.decrypt(enc_email)
    password = autumn.decrypt(enc_password)
    if User.query.filter_by(encrypted_email=enc_email).first():
        return jsonify({'success': False, 'error': 'User exists'}), 400
    user = User(encrypted_email=enc_email, encrypted_password=enc_password)
    db.session.add(user)
    db.session.commit()
    return jsonify({'success': True}), 201

@app.route('/api/login', methods=['POST'])
def login():
    data = request.json
    enc_email = data.get('email')
    enc_password = data.get('password')
    user = User.query.filter_by(encrypted_email=enc_email).first()
    if user and user.encrypted_password == enc_password:
        return jsonify({'success': True}), 200
    return jsonify({'success': False, 'error': 'Invalid credentials'}), 401

@app.route('/api/chat', methods=['POST'])
def chat():
    data = request.json
    message = data.get('message')
    reply = autumn.generate_reply(message)
    return jsonify({'reply': reply}), 200

@app.route('/', methods=['GET'])
def index():
    return app.send_static_file('index.html')

if __name__ == '__main__':
    port = int(os.getenv('PORT', 8080))
    app.run(host='0.0.0.0', port=port)
bl_info = {
    "name": "Reflex Potentials - Physics Matched",
    "author": "Radical Deepscale | DART Meadow",
    "version": (1, 0, 3),
    "blender": (5, 0, 1),
    "location": "Node Editor > Sidebar > Reflex Potentials | 3D Viewport > Sidebar > Reflex Potentials",
    "description": "FRP Shell Hierarchical Buoyancy Matrix - JavaScript Physics Implementation",
    "category": "Node",
}

"""
==============================================================================
REFLEX POTENTIALS: JAVASCRIPT PHYSICS IMPLEMENTATION
==============================================================================

This is a complete rewrite to match the EXACT execution logic from the 
JavaScript/Three.js implementation in reflexpotentials.html

Key Matching Elements:
1. InteractiveHabitat class with identical physics calculations
2. Frame-by-frame simulation with proper gear shaft accumulator
3. Exact buoyancy forces and velocity dampening
4. Matching repulsion, center pull, and rotation
5. Neuron physics with centroid-based buoyancy
6. Identical pulse behavior and decay
7. Shell boundary limits
==============================================================================
"""

import bpy
import math
import random
from mathutils import Vector, Euler
from bpy.types import Operator, Panel, PropertyGroup
from bpy.props import (
    FloatProperty, 
    IntProperty, 
    BoolProperty, 
    EnumProperty, 
    PointerProperty,
    StringProperty
)

# ==============================================================================
# SIMULATION CONFIGURATION - Matches JavaScript SIM_CONFIG
# ==============================================================================

class SimulationConfig:
    """
    Global simulation configuration matching the JavaScript version.
    These values are updated from UI controls.
    """
    def __init__(self):
        self.rot_speed = 0.01
        self.viscosity = 0.98
        self.repulsion_force = 0.05
        self.center_pull = 0.005
        self.zoom = 25
        
    def update_from_settings(self, settings):
        """Update configuration from Blender property group"""
        # Rotation speed mapping (0-100 slider -> 0-0.05 rotation)
        self.rot_speed = settings.rotation_speed * 0.0005
        
        # Viscosity mapping (0-100 slider -> 1.0-0.95 viscosity)
        # Higher slider value = more drag = lower viscosity multiplier
        self.viscosity = 1.0 - (settings.env_viscosity * 0.0005)
        
        # Repulsion force mapping (0-200 slider -> 0-0.2 force)
        self.repulsion_force = settings.env_repulsion * 0.001

# Global simulation config instance
SIM_CONFIG = SimulationConfig()

# ==============================================================================
# INTERACTIVE HABITAT - Matches JavaScript InteractiveHabitat class
# ==============================================================================

class InteractiveHabitat:
    """
    Exact Python implementation of the JavaScript InteractiveHabitat class.
    
    This class manages a single habitat unit consisting of:
    - 3 gravitational bodies (Geo, Fluid, Aero) in pyramid formation
    - 1 neuron that floats in the median
    - Physics simulation matching JavaScript behavior
    """
    
    def __init__(self, is_master, habitat_id, start_pos, settings):
        self.is_master = is_master
        self.id = habitat_id
        self.name = "Master_Node" if is_master else f"Replica_{habitat_id}"
        
        # Buoyancy values from settings
        self.f_aero = settings.f_aero
        self.f_fluid = settings.f_fluid
        self.f_geo = settings.f_geo
        self.r = 0  # Pulse/reflex value
        self.p = 0  # Performance (unused in JS, kept for compatibility)
        
        # Physics vectors
        self.position = Vector(start_pos)
        self.velocity = Vector((
            (random.random() - 0.5) * 0.1,
            (random.random() - 0.5) * 0.1,
            (random.random() - 0.5) * 0.1
        ))
        self.acceleration = Vector((0, 0, 0))
        
        # Neuron physics
        self.neuron_position = Vector((0, 1, 0))  # Local position within habitat
        self.n_velocity = Vector((0, 0, 0))
        self.n_accel = Vector((0, 0, 0))
        
        # Rotation
        self.rotation_y = 0
        
        # Blender objects (will be created in build)
        self.group_object = None
        self.mesh_geo = None
        self.mesh_fluid = None
        self.mesh_aero = None
        self.neuron_object = None
        
    def update_physics(self, all_habitats):
        """
        Main physics update - EXACT match to JavaScript updatePhysics()
        
        Returns:
            float: Neuron velocity length (for arc calculation)
        """
        # 1. GLOBAL ROTATION (Galaxy Spin)
        self.rotation_y += SIM_CONFIG.rot_speed
        
        # 2. INTER-HABITAT REPULSION
        for other in all_habitats:
            if other.id != self.id:
                dist_vec = self.position - other.position
                dist = dist_vec.length
                
                if dist < 8:  # Interaction radius
                    # Inverse square law repulsion
                    force = SIM_CONFIG.repulsion_force / (dist * dist)
                    dist_vec.normalize()
                    self.acceleration += dist_vec * force
        
        # 3. CENTER PULL (Keeps system bounded)
        center_vec = Vector((0, 0, 0)) - self.position
        self.acceleration += center_vec * SIM_CONFIG.center_pull
        
        # 4. VELOCITY INTEGRATION
        self.velocity += self.acceleration
        self.velocity *= SIM_CONFIG.viscosity  # Damping
        self.position += self.velocity
        self.acceleration = Vector((0, 0, 0))  # Reset acceleration
        
        # 5. INTERNAL NEURON BUOYANCY PHYSICS
        # Calculate centroid of the three gravity bodies
        # In JS: meshGeo at (2, -1.5, 0), meshFluid at (-1.5, -1.5, 1.5), meshAero at (-1.5, -1.5, -1.5)
        geo_local = Vector((2, -1.5, 0))
        fluid_local = Vector((-1.5, -1.5, 1.5))
        aero_local = Vector((-1.5, -1.5, -1.5))
        
        centroid = (geo_local + fluid_local + aero_local) / 3.0
        
        # 6. PULL NEURON TOWARD CENTROID (f_aero influence)
        to_centroid = centroid - self.neuron_position
        dist_to_c = to_centroid.length
        
        if dist_to_c > 0.2:  # Minimum distance threshold
            to_centroid.normalize()
            self.n_accel += to_centroid * (self.f_aero * 0.0001)
        
        # 7. UPWARD LIFT (f_fluid influence)
        lift = Vector((0, 1, 0)) * (self.f_fluid * 0.0002)
        self.n_accel += lift
        
        # 8. PULSE TURBULENCE (r decay)
        if self.r > 0:
            self.n_accel.x += (random.random() - 0.5) * (self.r * 0.002)
            self.n_accel.y += (random.random() - 0.5) * (self.r * 0.002)
            self.n_accel.z += (random.random() - 0.5) * (self.r * 0.002)
            self.r *= 0.95  # Exponential decay
        
        # 9. NEURON VELOCITY INTEGRATION
        self.n_velocity += self.n_accel
        self.n_velocity *= 0.96  # Neuron-specific damping
        self.neuron_position += self.n_velocity
        self.n_accel = Vector((0, 0, 0))  # Reset
        
        # 10. SHELL BOUNDARY CONSTRAINT
        shell_limit = 4.0
        neuron_distance = self.neuron_position.length
        
        if neuron_distance > shell_limit:
            # Normalize to shell limit and reverse velocity
            self.neuron_position = self.neuron_position.normalized() * shell_limit
            self.n_velocity *= -0.5  # Bounce with energy loss
        
        # Return neuron velocity length (this is the "arc" contribution)
        return self.n_velocity.length
    
    def pulse(self, energy):
        """Add pulse energy - matches JavaScript pulse() method"""
        self.r += energy
    
    def update_blender_objects(self):
        """Update Blender object transforms from physics state"""
        if self.group_object:
            # Update habitat group position and rotation
            self.group_object.location = self.position
            self.group_object.rotation_euler.y = self.rotation_y
            
        if self.neuron_object:
            # Update neuron local position
            self.neuron_object.location = self.neuron_position
    
    def update_shell_values(self, settings):
        """Update shell values from settings"""
        self.f_geo = settings.f_geo
        self.f_fluid = settings.f_fluid
        self.f_aero = settings.f_aero


# ==============================================================================
# HABITAT BUILDER - Creates Blender geometry
# ==============================================================================

class HabitatBuilder:
    """Builds Blender geometry for habitats"""
    
    @staticmethod
    def build_habitat_geometry(habitat, settings):
        """
        Create Blender objects for a habitat.
        Matches the JavaScript mesh creation.
        """
        # Create parent empty for the habitat group
        bpy.ops.object.empty_add(type='PLAIN_AXES', location=habitat.position)
        habitat.group_object = bpy.context.active_object
        habitat.group_object.name = habitat.name
        
        # Create materials
        mat_geo = HabitatBuilder.create_material("Mat_Geo", (0.96, 0.62, 0.04))  # Gold
        mat_fluid = HabitatBuilder.create_material("Mat_Fluid", (0.12, 0.25, 0.69))  # Deep Blue
        mat_aero = HabitatBuilder.create_material("Mat_Aero", (0.85, 0.27, 0.94))  # Purple
        
        # Neuron color: Master = red, Replica = sky blue
        neuron_color = (1.0, 0.0, 0.27) if habitat.is_master else (0.0, 0.75, 1.0)
        mat_neuron = HabitatBuilder.create_emissive_material("Mat_Neuron", neuron_color)
        
        # Create three gravity spheres
        # Positions match JavaScript: geo(2,-1.5,0), fluid(-1.5,-1.5,1.5), aero(-1.5,-1.5,-1.5)
        habitat.mesh_geo = HabitatBuilder.create_sphere(
            f"{habitat.name}_Geo", 
            Vector((2, -1.5, 0)), 
            0.4, 
            mat_geo,
            habitat.group_object
        )
        
        habitat.mesh_fluid = HabitatBuilder.create_sphere(
            f"{habitat.name}_Fluid",
            Vector((-1.5, -1.5, 1.5)),
            0.4,
            mat_fluid,
            habitat.group_object
        )
        
        habitat.mesh_aero = HabitatBuilder.create_sphere(
            f"{habitat.name}_Aero",
            Vector((-1.5, -1.5, -1.5)),
            0.4,
            mat_aero,
            habitat.group_object
        )
        
        # Create neuron
        habitat.neuron_object = HabitatBuilder.create_sphere(
            f"{habitat.name}_Neuron",
            habitat.neuron_position,
            0.6,
            mat_neuron,
            habitat.group_object
        )
        
        # Create connecting lines (edges)
        HabitatBuilder.create_pyramid_edges(habitat)
        
        # Setup geometry nodes to make everything visible in node editor
        setup_geometry_nodes_for_habitat(habitat, settings)
        
        return habitat
    
    @staticmethod
    def create_material(name, color):
        """Create a standard material"""
        mat = bpy.data.materials.get(name)
        if not mat:
            mat = bpy.data.materials.new(name)
        mat.use_nodes = True
        nodes = mat.node_tree.nodes
        nodes.clear()
        
        bsdf = nodes.new('ShaderNodeBsdfPrincipled')
        bsdf.inputs['Base Color'].default_value = (*color, 1.0)
        bsdf.inputs['Metallic'].default_value = 0.3
        bsdf.inputs['Roughness'].default_value = 0.4
        
        output = nodes.new('ShaderNodeOutputMaterial')
        mat.node_tree.links.new(bsdf.outputs['BSDF'], output.inputs['Surface'])
        
        return mat
    
    @staticmethod
    def create_emissive_material(name, color):
        """Create an emissive material for neurons"""
        mat = bpy.data.materials.get(name)
        if not mat:
            mat = bpy.data.materials.new(name)
        mat.use_nodes = True
        nodes = mat.node_tree.nodes
        nodes.clear()
        
        bsdf = nodes.new('ShaderNodeBsdfPrincipled')
        bsdf.inputs['Base Color'].default_value = (*color, 1.0)
        bsdf.inputs['Emission Color'].default_value = (*color, 1.0)
        bsdf.inputs['Emission Strength'].default_value = 2.0
        
        output = nodes.new('ShaderNodeOutputMaterial')
        mat.node_tree.links.new(bsdf.outputs['BSDF'], output.inputs['Surface'])
        
        return mat
    
    @staticmethod
    def create_sphere(name, location, radius, material, parent):
        """Create a sphere mesh"""
        bpy.ops.mesh.primitive_uv_sphere_add(
            radius=radius,
            segments=32,
            ring_count=16,
            location=(0, 0, 0)
        )
        obj = bpy.context.active_object
        obj.name = name
        obj.location = location
        obj.parent = parent
        
        if obj.data.materials:
            obj.data.materials[0] = material
        else:
            obj.data.materials.append(material)
        
        return obj
    
    @staticmethod
    def create_pyramid_edges(habitat):
        """Create the connecting lines between gravity bodies"""
        # Positions of the three bodies
        geo_pos = Vector((2, -1.5, 0))
        fluid_pos = Vector((-1.5, -1.5, 1.5))
        aero_pos = Vector((-1.5, -1.5, -1.5))
        apex_pos = Vector((0, 1, 0))
        
        # Create curve for pyramid edges
        curve_data = bpy.data.curves.new(f"{habitat.name}_Edges", 'CURVE')
        curve_data.dimensions = '3D'
        curve_data.bevel_depth = 0.02
        
        # Base triangle
        HabitatBuilder.add_line_segment(curve_data, geo_pos, fluid_pos)
        HabitatBuilder.add_line_segment(curve_data, fluid_pos, aero_pos)
        HabitatBuilder.add_line_segment(curve_data, aero_pos, geo_pos)
        
        # Lines to apex
        HabitatBuilder.add_line_segment(curve_data, geo_pos, apex_pos)
        HabitatBuilder.add_line_segment(curve_data, fluid_pos, apex_pos)
        HabitatBuilder.add_line_segment(curve_data, aero_pos, apex_pos)
        
        # Create object
        curve_obj = bpy.data.objects.new(f"{habitat.name}_Edges", curve_data)
        bpy.context.scene.collection.objects.link(curve_obj)
        curve_obj.parent = habitat.group_object
        
        # Material
        mat = bpy.data.materials.new(f"Mat_Edges_{habitat.id}")
        mat.use_nodes = True
        mat.node_tree.nodes["Principled BSDF"].inputs[0].default_value = (0.2, 0.25, 0.33, 0.3)
        curve_obj.data.materials.append(mat)
    
    @staticmethod
    def add_line_segment(curve_data, start, end):
        """Add a single line segment to curve"""
        spline = curve_data.splines.new('POLY')
        spline.points.add(1)  # Add one more point (already has one)
        spline.points[0].co = (*start, 1)
        spline.points[1].co = (*end, 1)


# ==============================================================================
# GEOMETRY NODE API - Makes existing geometry visible in node editor
# ==============================================================================

def setup_geometry_nodes_for_habitat(habitat, settings):
    """
    Creates a geometry node setup that references the existing mesh objects.
    This makes the habitat's geometry appear and be controllable in the node editor.
    
    This doesn't replace the geometry - it just creates node tree infrastructure
    that references the already-created objects so they show up in the node editor.
    """
    if not habitat.neuron_object:
        return
    
    # Get or create geometry nodes modifier on the neuron object
    modifier = habitat.neuron_object.modifiers.get("GeometryNodes")
    if not modifier:
        modifier = habitat.neuron_object.modifiers.new("GeometryNodes", 'NODES')
    
    # Create unique node group for this habitat
    group_name = f"Habitat_Nodes_{habitat.id}"
    node_tree = bpy.data.node_groups.get(group_name)
    
    if not node_tree:
        node_tree = bpy.data.node_groups.new(group_name, 'GeometryNodeTree')
    
    modifier.node_group = node_tree
    
    # If already built, skip
    if len(node_tree.nodes) > 0:
        return
    
    # Setup interface (Blender 5.0 API)
    for item in list(node_tree.interface.items_tree):
        node_tree.interface.remove(item)
    
    # Add geometry input/output
    node_tree.interface.new_socket(
        name="Geometry",
        in_out='INPUT',
        socket_type='NodeSocketGeometry'
    )
    node_tree.interface.new_socket(
        name="Geometry",
        in_out='OUTPUT',
        socket_type='NodeSocketGeometry'
    )
    
    nodes = node_tree.nodes
    links = node_tree.links
    
    # Create basic node structure
    group_input = nodes.new('NodeGroupInput')
    group_input.location = (-400, 0)
    
    group_output = nodes.new('NodeGroupOutput')
    group_output.location = (400, 0)
    
    # Object Info nodes to bring in the existing geometry
    shell_objects = []
    y_offset = 200
    
    # Add the three shell spheres
    for obj_attr, label in [
        ('mesh_geo', 'Geo Shell'),
        ('mesh_fluid', 'Fluid Shell'),
        ('mesh_aero', 'Aero Shell')
    ]:
        obj = getattr(habitat, obj_attr, None)
        if obj:
            obj_info = nodes.new('GeometryNodeObjectInfo')
            obj_info.location = (-600, y_offset)
            obj_info.inputs['Object'].default_value = obj
            obj_info.label = label
            shell_objects.append(obj_info)
            y_offset -= 150
    
    # Join all geometry together
    join_node = nodes.new('GeometryNodeJoinGeometry')
    join_node.location = (200, 0)
    
    # Connect input geometry (the neuron)
    links.new(group_input.outputs['Geometry'], join_node.inputs['Geometry'])
    
    # Connect shell objects
    for obj_info in shell_objects:
        links.new(obj_info.outputs['Geometry'], join_node.inputs['Geometry'])
    
    # Output
    links.new(join_node.outputs['Geometry'], group_output.inputs['Geometry'])
    
    print(f"✓ Geometry node API set up for {habitat.name}")


# ==============================================================================
# PROPERTY GROUP - UI Settings
# ==============================================================================

class ReflexSettings(PropertyGroup):
    """Settings for the Reflex Potentials simulation"""
    
    # Shell factors (matching JavaScript sliders)
    f_geo: FloatProperty(
        name="f3: Geological",
        description="Geological buoyancy factor",
        default=150.0,
        min=10.0,
        max=300.0
    )
    
    f_fluid: FloatProperty(
        name="f2: Fluid",
        description="Fluid/Maritime buoyancy factor",
        default=100.0,
        min=10.0,
        max=300.0
    )
    
    f_aero: FloatProperty(
        name="f1: Aerospace Root",
        description="Aerospace ROOT buoyancy factor",
        default=80.0,
        min=10.0,
        max=300.0
    )
    
    r_pulse: FloatProperty(
        name="Pulse Strength",
        description="Reflex pulse energy",
        default=50.0,
        min=0.0,
        max=200.0
    )
    
    # Environment controls
    rotation_speed: IntProperty(
        name="Galaxy Rotation",
        description="System rotation speed",
        default=10,
        min=0,
        max=100
    )
    
    env_viscosity: IntProperty(
        name="Viscosity",
        description="Medium viscosity (drag)",
        default=20,
        min=0,
        max=100
    )
    
    env_repulsion: IntProperty(
        name="Repulsion",
        description="Habitat repulsion force",
        default=80,
        min=0,
        max=200
    )
    
    # Simulation state
    is_simulating: BoolProperty(
        name="Simulation Running",
        description="Whether simulation is currently running",
        default=False
    )
    
    frame_counter: IntProperty(
        name="Frame Counter",
        description="Current simulation frame",
        default=0
    )
    
    gear_shaft_accumulator: FloatProperty(
        name="Gear Shaft Accumulator",
        description="Accumulated arc values",
        default=0.0
    )


# ==============================================================================
# SIMULATION MANAGER - Manages all habitats and frame updates
# ==============================================================================

class SimulationManager:
    """
    Manages the global simulation state and habitat list.
    This matches the JavaScript global state management.
    """
    
    def __init__(self):
        self.habitats = []
        self.id_counter = 0
        self.gear_shaft_accumulator = 0.0
    
    def add_master_habitat(self, settings):
        """Create the master habitat"""
        habitat = InteractiveHabitat(
            is_master=True,
            habitat_id=self.id_counter,
            start_pos=(0, 0, 0),
            settings=settings
        )
        self.id_counter += 1
        
        HabitatBuilder.build_habitat_geometry(habitat, settings)
        self.habitats.append(habitat)
        return habitat
    
    def add_replica_habitat(self, settings):
        """Create a replica habitat at random position"""
        range_val = 10
        start_pos = (
            (random.random() - 0.5) * range_val,
            (random.random() - 0.5) * range_val,
            (random.random() - 0.5) * range_val
        )
        
        habitat = InteractiveHabitat(
            is_master=False,
            habitat_id=self.id_counter,
            start_pos=start_pos,
            settings=settings
        )
        self.id_counter += 1
        
        HabitatBuilder.build_habitat_geometry(habitat, settings)
        self.habitats.append(habitat)
        return habitat
    
    def clear_all(self):
        """Clear all habitats"""
        for habitat in self.habitats:
            if habitat.group_object:
                # Delete all children first
                for child in habitat.group_object.children[:]:
                    bpy.data.objects.remove(child, do_unlink=True)
                # Delete the group object
                bpy.data.objects.remove(habitat.group_object, do_unlink=True)
        
        self.habitats = []
        self.id_counter = 0
        self.gear_shaft_accumulator = 0.0
    
    def update_frame(self, settings):
        """
        Main simulation update - matches JavaScript animate() function.
        
        This is called every frame by the frame handler.
        """
        # Update config from settings
        SIM_CONFIG.update_from_settings(settings)
        
        # Physics loop - matches JavaScript physics update
        total_frame_arc = 0.0
        
        for habitat in self.habitats:
            arc = habitat.update_physics(self.habitats)
            total_frame_arc += arc
            habitat.update_blender_objects()
        
        # Lifespan logic - matches JavaScript
        self.gear_shaft_accumulator += total_frame_arc
        retro_deduction = total_frame_arc / 8.0
        
        # Store values in settings
        settings.gear_shaft_accumulator = self.gear_shaft_accumulator
        settings.frame_counter += 1
        
        return total_frame_arc, retro_deduction
    
    def pulse_all(self, energy):
        """Pulse all habitats"""
        for habitat in self.habitats:
            habitat.pulse(energy)
    
    def stabilize_all(self):
        """Reset all pulse and velocities"""
        for habitat in self.habitats:
            habitat.r = 0
            habitat.n_velocity = Vector((0, 0, 0))
            habitat.velocity *= 0.1
    
    def update_shell_values(self, settings):
        """Update all habitat shell values"""
        for habitat in self.habitats:
            habitat.update_shell_values(settings)


# Global simulation manager instance
sim_manager = SimulationManager()


# ==============================================================================
# FRAME HANDLER - Drives the simulation
# ==============================================================================

def simulation_frame_handler(scene):
    """
    Blender frame change handler.
    This is called automatically every frame and drives the simulation.
    """
    settings = scene.reflex_potentials
    
    if settings.is_simulating and len(sim_manager.habitats) > 0:
        sim_manager.update_frame(settings)


# ==============================================================================
# OPERATORS - UI Actions
# ==============================================================================

class REF_OT_Build(Operator):
    """Build the initial habitat system"""
    bl_idname = "reflex.build"
    bl_label = "Build System"
    bl_description = "Create the master habitat"
    
    def execute(self, context):
        settings = context.scene.reflex_potentials
        
        # Clear existing
        sim_manager.clear_all()
        
        # Create master
        sim_manager.add_master_habitat(settings)
        
        # Setup scene
        self.setup_scene(context)
        
        # Start simulation
        settings.is_simulating = True
        settings.frame_counter = 0
        settings.gear_shaft_accumulator = 0.0
        
        self.report({'INFO'}, "System built successfully")
        return {'FINISHED'}
    
    def setup_scene(self, context):
        """Setup Blender scene for simulation"""
        scene = context.scene
        
        # Set frame range
        scene.frame_start = 1
        scene.frame_end = 10000
        scene.frame_current = 1
        
        # Setup world
        if not scene.world:
            scene.world = bpy.data.worlds.new("World")
        
        scene.world.use_nodes = True
        nodes = scene.world.node_tree.nodes
        nodes.clear()
        
        bg = nodes.new('ShaderNodeBackground')
        bg.inputs[0].default_value = (0.06, 0.09, 0.16, 1.0)  # Dark blue
        
        output = nodes.new('ShaderNodeOutputWorld')
        scene.world.node_tree.links.new(bg.outputs[0], output.inputs[0])
        
        # Setup camera
        if not context.scene.camera:
            bpy.ops.object.camera_add(location=(0, 10, 35))
            context.scene.camera = context.active_object


class REF_OT_Replicate(Operator):
    """Add a replica habitat"""
    bl_idname = "reflex.replicate"
    bl_label = "Add Replica"
    bl_description = "Create a replica habitat"
    
    def execute(self, context):
        settings = context.scene.reflex_potentials
        
        if len(sim_manager.habitats) == 0:
            self.report({'WARNING'}, "Build system first")
            return {'CANCELLED'}
        
        sim_manager.add_replica_habitat(settings)
        
        self.report({'INFO'}, f"Replica added ({len(sim_manager.habitats)} total)")
        return {'FINISHED'}


class REF_OT_InsertPulse(Operator):
    """Insert pulse into all habitats"""
    bl_idname = "reflex.insert_pulse"
    bl_label = "Insert Pulse"
    bl_description = "Inject pulse energy into all habitats"
    
    def execute(self, context):
        settings = context.scene.reflex_potentials
        
        if len(sim_manager.habitats) == 0:
            self.report({'WARNING'}, "Build system first")
            return {'CANCELLED'}
        
        sim_manager.pulse_all(settings.r_pulse)
        
        self.report({'INFO'}, f"Pulse injected: {settings.r_pulse}")
        return {'FINISHED'}


class REF_OT_Stabilize(Operator):
    """Stabilize all habitats"""
    bl_idname = "reflex.stabilize"
    bl_label = "Stabilize"
    bl_description = "Reset pulse and reduce velocities"
    
    def execute(self, context):
        if len(sim_manager.habitats) == 0:
            self.report({'WARNING'}, "Build system first")
            return {'CANCELLED'}
        
        sim_manager.stabilize_all()
        
        self.report({'INFO'}, "System stabilized")
        return {'FINISHED'}


class REF_OT_Reset(Operator):
    """Reset entire system"""
    bl_idname = "reflex.reset"
    bl_label = "Reset System"
    bl_description = "Clear all habitats and reset simulation"
    
    def execute(self, context):
        settings = context.scene.reflex_potentials
        
        sim_manager.clear_all()
        settings.is_simulating = False
        settings.frame_counter = 0
        settings.gear_shaft_accumulator = 0.0
        
        self.report({'INFO'}, "System reset")
        return {'FINISHED'}


class REF_OT_ToggleSimulation(Operator):
    """Toggle simulation on/off"""
    bl_idname = "reflex.toggle_simulation"
    bl_label = "Toggle Simulation"
    bl_description = "Start/stop the physics simulation"
    
    def execute(self, context):
        settings = context.scene.reflex_potentials
        settings.is_simulating = not settings.is_simulating
        
        status = "started" if settings.is_simulating else "paused"
        self.report({'INFO'}, f"Simulation {status}")
        return {'FINISHED'}


class REF_OT_UpdateShells(Operator):
    """Update shell values for all habitats"""
    bl_idname = "reflex.update_shells"
    bl_label = "Update Shells"
    bl_description = "Update shell values for all habitats"
    
    def execute(self, context):
        settings = context.scene.reflex_potentials
        
        if len(sim_manager.habitats) == 0:
            return {'CANCELLED'}
        
        sim_manager.update_shell_values(settings)
        return {'FINISHED'}


# ==============================================================================
# PANEL - User Interface
# ==============================================================================

class REF_PT_Main(Panel):
    """Main panel for Reflex Potentials"""
    bl_label = "Reflex Potentials"
    bl_idname = "REF_PT_Main"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Reflex Potentials'
    
    def draw(self, context):
        layout = self.layout
        settings = context.scene.reflex_potentials
        
        # Build/Reset controls
        box = layout.box()
        box.label(text="System Control", icon='PHYSICS')
        
        row = box.row(align=True)
        row.scale_y = 1.5
        row.operator("reflex.build", icon='PLUS')
        row.operator("reflex.reset", icon='TRASH')
        
        box.separator()
        
        # Simulation toggle
        row = box.row()
        row.scale_y = 1.3
        if settings.is_simulating:
            row.operator("reflex.toggle_simulation", text="Pause Simulation", icon='PAUSE')
        else:
            row.operator("reflex.toggle_simulation", text="Start Simulation", icon='PLAY')
        
        # Status
        box.separator()
        row = box.row()
        row.label(text=f"Habitats: {len(sim_manager.habitats)}")
        row = box.row()
        row.label(text=f"Frame: {settings.frame_counter}")
        row = box.row()
        row.label(text=f"Gear Shaft: {settings.gear_shaft_accumulator:.4f}")
        
        layout.separator()
        
        # Environment controls
        box = layout.box()
        box.label(text="Environment Physics", icon='WORLD')
        box.prop(settings, "rotation_speed")
        box.prop(settings, "env_viscosity")
        box.prop(settings, "env_repulsion")
        
        layout.separator()
        
        # Shell factors
        box = layout.box()
        box.label(text="Shell Factors", icon='SPHERE')
        
        col = box.column(align=True)
        col.prop(settings, "f_geo")
        col.prop(settings, "f_fluid")
        col.prop(settings, "f_aero")
        
        box.operator("reflex.update_shells", icon='FILE_REFRESH')
        
        layout.separator()
        
        # Pulse controls
        box = layout.box()
        box.label(text="Pulse Controls", icon='FORCE_TURBULENCE')
        box.prop(settings, "r_pulse")
        
        row = box.row(align=True)
        row.scale_y = 1.3
        row.operator("reflex.insert_pulse", icon='PLUS')
        row.operator("reflex.stabilize", icon='LOOP_BACK')
        
        layout.separator()
        
        # Habitat controls
        box = layout.box()
        box.label(text="Habitat Management", icon='OUTLINER_OB_GROUP_INSTANCE')
        box.operator("reflex.replicate", icon='DUPLICATE')


# ==============================================================================
# REGISTRATION
# ==============================================================================

classes = (
    ReflexSettings,
    REF_OT_Build,
    REF_OT_Replicate,
    REF_OT_InsertPulse,
    REF_OT_Stabilize,
    REF_OT_Reset,
    REF_OT_ToggleSimulation,
    REF_OT_UpdateShells,
    REF_PT_Main,
)

def register():
    """Register addon"""
    for cls in classes:
        bpy.utils.register_class(cls)
    
    bpy.types.Scene.reflex_potentials = PointerProperty(type=ReflexSettings)
    
    # Add frame handler
    if simulation_frame_handler not in bpy.app.handlers.frame_change_post:
        bpy.app.handlers.frame_change_post.append(simulation_frame_handler)
    
    print("=" * 70)
    print("✓ Reflex Potentials v3.0.0 - Physics Matched registered")
    print("=" * 70)

def unregister():
    """Unregister addon"""
    # Remove frame handler
    if simulation_frame_handler in bpy.app.handlers.frame_change_post:
        bpy.app.handlers.frame_change_post.remove(simulation_frame_handler)
    
    del bpy.types.Scene.reflex_potentials
    
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    
    print("=" * 70)
    print("✓ Reflex Potentials unregistered")
    print("=" * 70)

if __name__ == "__main__":
    register()
